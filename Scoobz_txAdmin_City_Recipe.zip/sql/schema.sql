CREATE TABLE IF NOT EXISTS `scoobz_characters` (
 `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
 `license` VARCHAR(100) NOT NULL,
 `firstname` VARCHAR(40) NOT NULL,
 `lastname` VARCHAR(40) NOT NULL,
 `dob` VARCHAR(10) NOT NULL,
 `gender` VARCHAR(16) NOT NULL,
 `cash` INT NOT NULL DEFAULT 500,
 `bank` INT NOT NULL DEFAULT 5000,
 `job` VARCHAR(40) NOT NULL DEFAULT 'unemployed',
 `grade` INT NOT NULL DEFAULT 0,
 `inventory` LONGTEXT NOT NULL,
 `position` LONGTEXT NOT NULL,
 `metadata` LONGTEXT NOT NULL,
 `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`id`), INDEX `idx_license` (`license`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS `scoobz_vehicles` (
 `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
 `owner_id` INT UNSIGNED NOT NULL,
 `plate` VARCHAR(10) NOT NULL,
 `model` VARCHAR(50) NOT NULL,
 `props` LONGTEXT NOT NULL,
 `stored` TINYINT(1) NOT NULL DEFAULT 1,
 PRIMARY KEY (`id`), UNIQUE KEY `uniq_plate` (`plate`), INDEX `idx_owner` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `scoobz_audit` (
 `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
 `actor_character_id` INT UNSIGNED NULL,
 `target_character_id` INT UNSIGNED NULL,
 `action` VARCHAR(64) NOT NULL,
 `details` LONGTEXT NOT NULL,
 `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`id`), KEY `idx_actor` (`actor_character_id`), KEY `idx_target` (`target_character_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
