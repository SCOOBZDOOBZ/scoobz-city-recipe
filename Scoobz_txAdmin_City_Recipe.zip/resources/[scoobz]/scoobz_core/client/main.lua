local active,playerData=false,nil
local pending,sequence={},0
local openScreen=nil
local function request(action,data,cb)
 sequence=sequence+1
 local token=sequence
 pending[token]=cb
 TriggerServerEvent('scoobz:request',token,action,data or {})
 SetTimeout(12000,function()
  if pending[token] then local fn=pending[token];pending[token]=nil;fn({error='Request timed out'}) end
 end)
end
RegisterNetEvent('scoobz:response',function(token,result)
 local cb=pending[token];if cb then pending[token]=nil;cb(result or {}) end
end)
local function notify(msg)
 SendNUIMessage({type='notify',message=msg})
 TriggerEvent('chat:addMessage',{args={'Scoobz',tostring(msg)}})
end
RegisterNetEvent('scoobz:notify',notify)
RegisterNetEvent('scoobz:sync',function(data)
 playerData=data;active=true
 SendNUIMessage({type='player',data=data})
end)
local function ui(screen,data)
 openScreen=screen
 SetNuiFocus(screen~=nil,screen~=nil)
 SendNUIMessage({type='screen',screen=screen,data=data or {},config={city=Config.CityName,items=Config.Items,jobs=Config.Jobs}})
end
local function spawn(pos)
 pos=pos or Config.DefaultSpawn
 local ped=PlayerPedId()
 DoScreenFadeOut(500);Wait(600)
 RequestCollisionAtCoord(pos.x,pos.y,pos.z)
 SetEntityCoordsNoOffset(ped,pos.x,pos.y,pos.z,false,false,false)
 SetEntityHeading(ped,pos.w or 0)
 NetworkResurrectLocalPlayer(pos.x,pos.y,pos.z,pos.w or 0,true,false)
 SetEntityInvincible(ped,false)
 FreezeEntityPosition(ped,false)
 ClearPedTasksImmediately(ped)
 Wait(700);DoScreenFadeIn(700)
end
local function characterMenu()
 active=false;playerData=nil
 request('characters',{},function(res)
  if res.error then notify(res.error) else ui('characters',res) end
 end)
end
CreateThread(function()
 Wait(1000)
 ShutdownLoadingScreenNui()
 characterMenu()
end)
RegisterNUICallback('action',function(data,cb)
 local action=data.action
 if action=='close' then
  if active then ui(nil) end
  cb({success=active});return
 end
 request(action,data.payload or {},function(result)
  if result.success and action=='select' then
   playerData=result.player;active=true;ui(nil);spawn(result.player.position)
  elseif result.success and action=='create' then
   characterMenu()
  elseif result.error then notify(result.error)
  end
  cb(result)
 end)
end)
RegisterCommand('city',function()
 if active then ui(openScreen and nil or 'dashboard',{player=playerData}) end
end)
RegisterKeyMapping('city','Scoobz City Dashboard','keyboard','F2')
RegisterCommand('inventory',function()
 if active then ui(openScreen and nil or 'inventory',{player=playerData}) end
end)
RegisterKeyMapping('inventory','Scoobz Inventory','keyboard','F3')
RegisterCommand('bank',function()
 if active then ui('bank',{player=playerData}) end
end)
RegisterCommand('charinfo',function()
 if playerData then notify(('%s %s | ID %d | %s'):format(playerData.firstname,playerData.lastname,playerData.id,playerData.job)) end
end)
CreateThread(function()
 while true do
  Wait(1000)
  if active and playerData then
   SendNUIMessage({type='hud',show=true,data=playerData})
  end
 end
end)
CreateThread(function()
 while true do
  Wait(20000)
  if active then
   local ped=PlayerPedId();local c=GetEntityCoords(ped)
   TriggerServerEvent('scoobz:updatePosition',{x=c.x,y=c.y,z=c.z,w=GetEntityHeading(ped)})
  end
 end
end)
local markers={}
for i,s in ipairs(Config.Shops) do markers[#markers+1]={kind='shop',index=i,name=s.name,coords=s.coords} end
for i,g in ipairs(Config.Garages) do markers[#markers+1]={kind='garage',index=i,name=g.name,coords=g.coords} end
CreateThread(function()
 while true do
  local sleep=1200
  if active then
   local c=GetEntityCoords(PlayerPedId())
   for _,m in ipairs(markers) do
    local d=#(c-vector3(m.coords.x,m.coords.y,m.coords.z))
    if d<22.0 then
     sleep=0
     DrawMarker(2,m.coords.x,m.coords.y,m.coords.z+0.3,0,0,0,0,0,0,0.28,0.28,0.28,28,190,225,170,false,true,2,false,nil,nil,false)
     if d<2.0 then
      BeginTextCommandDisplayHelp('STRING');AddTextComponentSubstringPlayerName('Press ~INPUT_CONTEXT~ for '..m.name);EndTextCommandDisplayHelp(0,false,true,-1)
      if IsControlJustReleased(0,38) then
       if m.kind=='shop' then ui('shop',{shop=m.index,items=Config.Shops[m.index].items})
       else
        request('vehicles',{},function(result)
         if result.error then notify(result.error) else ui('garage',{garage=m.index,vehicles=result.vehicles}) end
        end)
       end
      end
     end
    end
   end
  end
  Wait(sleep)
 end
end)
RegisterNetEvent('scoobz:healBandage',function()
 local ped=PlayerPedId();SetEntityHealth(ped,math.min(GetEntityMaxHealth(ped),GetEntityHealth(ped)+25))
end)
RegisterNetEvent('scoobz:spawnOwnedVehicle',function(row,where)
 local hash=joaat(row.model)
 if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then return notify('Invalid vehicle model: '..row.model) end
 RequestModel(hash);local elapsed=GetGameTimer()
 while not HasModelLoaded(hash) and GetGameTimer()-elapsed<6000 do Wait(50) end
 if not HasModelLoaded(hash) then return notify('Vehicle model could not load') end
 local veh=CreateVehicle(hash,where.x,where.y,where.z,where.w,true,false)
 if veh==0 then return notify('Vehicle spawn failed') end
 SetVehicleNumberPlateText(veh,row.plate)
 SetVehicleOnGroundProperly(veh)
 SetPedIntoVehicle(PlayerPedId(),veh,-1)
 SetModelAsNoLongerNeeded(hash)
 notify('Vehicle retrieved: '..row.plate)
end)
RegisterNetEvent('scoobz:deleteCurrentVehicle',function()
 local veh=GetVehiclePedIsIn(PlayerPedId(),false)
 if veh~=0 then NetworkRequestControlOfEntity(veh);Wait(100);SetEntityAsMissionEntity(veh,true,true);DeleteVehicle(veh) end
end)
RegisterCommand('storecar',function()
 if not active then return end
 local veh=GetVehiclePedIsIn(PlayerPedId(),false)
 if veh==0 then return notify('Enter your vehicle near a garage') end
 local plate=GetVehicleNumberPlateText(veh):gsub('%s+$','')
 request('storeVehicle',{plate=plate},function(result)
  if result.error then notify(result.error) else notify('Vehicle stored') end
 end)
end)
