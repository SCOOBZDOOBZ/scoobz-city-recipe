fx_version 'cerulean'
game 'gta5'
author 'Scoobz Scripts'
description 'Scoobz Framework standalone city foundation'
version '1.5.0'
shared_scripts {'shared/config.lua'}
server_scripts {'@oxmysql/lib/MySQL.lua','server/main.lua'}
client_scripts {'client/main.lua'}
ui_page 'html/index.html'
files {'html/index.html','html/style.css','html/app.js'}
dependency 'oxmysql'
