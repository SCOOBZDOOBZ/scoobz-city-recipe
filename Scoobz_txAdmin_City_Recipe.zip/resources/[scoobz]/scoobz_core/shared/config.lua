Config = {}
Config.CityName = 'Scoobz City'
Config.MaxCharacters = 3
Config.StartingCash = 500
Config.StartingBank = 5000
Config.MaxInventoryWeight = 30000
Config.AutosaveMs = 180000
Config.PaycheckMs = 1800000
Config.DefaultSpawn = {x=-1037.65,y=-2737.76,z=20.17,w=328.0}
Config.AdminAce = 'scoobz.admin'
Config.Items = {
 water={label='Water Bottle',weight=500,usable=true},
 sandwich={label='Sandwich',weight=350,usable=true},
 phone={label='Phone',weight=250,usable=false},
 bandage={label='Bandage',weight=100,usable=true},
 repairkit={label='Repair Kit',weight=900,usable=false}
}
Config.Jobs = {
 unemployed={label='Civilian',grades={[0]={label='Citizen',salary=100}}},
 police={label='Police Department',grades={[0]={label='Cadet',salary=500},[1]={label='Officer',salary=700},[2]={label='Sergeant',salary=950},[3]={label='Chief',salary=1400}}},
 ambulance={label='Emergency Medical Services',grades={[0]={label='Trainee',salary=500},[1]={label='Paramedic',salary=750},[2]={label='Consultant',salary=1050},[3]={label='Director',salary=1400}}},
 mechanic={label='Customs & Recovery',grades={[0]={label='Apprentice',salary=350},[1]={label='Technician',salary=550},[2]={label='Manager',salary=850}}},
 taxi={label='Scoobz Transit',grades={[0]={label='Driver',salary=250},[1]={label='Supervisor',salary=425}}}
}
Config.Shops = {
 {name='24/7 Supermarket',coords={x=25.74,y=-1345.45,z=29.50},items={water=10,sandwich=15,bandage=75}},
 {name='LTD Gasoline',coords={x=-48.39,y=-1757.91,z=29.42},items={water=10,sandwich=15}}
}
Config.Garages = {{name='Legion Garage',coords={x=215.08,y=-809.85,z=30.73},spawn={x=230.05,y=-798.75,z=30.57,w=157.0}}}
