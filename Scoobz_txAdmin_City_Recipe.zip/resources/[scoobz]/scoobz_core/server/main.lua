local Players, Busy, Callbacks = {}, {}, {}
local function log(action, detail)
 print(('[Scoobz] %s: %s'):format(action, tostring(detail)))
end
local function license(src)
 for _, id in ipairs(GetPlayerIdentifiers(src)) do
  if id:sub(1,8) == 'license:' then return id end
 end
end
local function validName(v)
 return type(v)=='string' and #v>=2 and #v<=40 and v:match('^[%a%s%-]+$') ~= nil
end
local function decode(s, fallback)
 if type(s)~='string' then return fallback end
 local ok,v=pcall(json.decode,s)
 return ok and type(v)=='table' and v or fallback
end
local function public(p)
 return {id=p.id,firstname=p.firstname,lastname=p.lastname,dob=p.dob,gender=p.gender,cash=p.cash,bank=p.bank,job=p.job,grade=p.grade,inventory=p.inventory,position=p.position,metadata=p.metadata,duty=p.metadata.duty == true}
end
local function notify(src,message)
 TriggerClientEvent('scoobz:notify',src,tostring(message))
end
local function sync(src)
 local p=Players[src]; if p then TriggerClientEvent('scoobz:sync',src,public(p)); if GetPlayerName(src) then Player(src).state:set('scoobz:job',p.job,true); Player(src).state:set('scoobz:duty',p.metadata.duty == true,true) end end
end
local function save(src)
 local p=Players[src]; if not p then return false end
 local success,err=pcall(function()
  MySQL.update.await('UPDATE scoobz_characters SET cash=?, bank=?, job=?, grade=?, inventory=?, position=?, metadata=? WHERE id=? AND license=?',
   {p.cash,p.bank,p.job,p.grade,json.encode(p.inventory),json.encode(p.position),json.encode(p.metadata),p.id,p.license})
 end)
 if not success then log('SAVE ERROR',err) end
 return success
end
local function isAdmin(src)
 return src==0 or IsPlayerAceAllowed(src,Config.AdminAce)
end
local function money(src,account,amount)
 local p=Players[src]
 if not p or (account~='cash' and account~='bank') then return false end
 amount=tonumber(amount)
 if not amount or amount%1~=0 or amount<1 or amount>100000000 then return false end
 if p[account]+amount>1000000000 then return false end
 p[account]=p[account]+amount; sync(src); return true
end
local function takeMoney(src,account,amount)
 local p=Players[src]
 if not p or (account~='cash' and account~='bank') then return false end
 amount=tonumber(amount)
 if not amount or amount%1~=0 or amount<1 or p[account]<amount then return false end
 p[account]=p[account]-amount;sync(src);return true
end
local function weight(p)
 local total=0
 for name,count in pairs(p.inventory) do
  if Config.Items[name] then total=total+Config.Items[name].weight*count end
 end
 return total
end
local function addItem(src,name,count)
 local p=Players[src];count=tonumber(count)
 if not p or not Config.Items[name] or not count or count%1~=0 or count<1 or count>1000 then return false end
 if weight(p)+Config.Items[name].weight*count>Config.MaxInventoryWeight then return false end
 p.inventory[name]=(p.inventory[name] or 0)+count;sync(src);return true
end
local function removeItem(src,name,count)
 local p=Players[src];count=tonumber(count)
 if not p or not Config.Items[name] or not count or count%1~=0 or count<1 or (p.inventory[name] or 0)<count then return false end
 p.inventory[name]=p.inventory[name]-count
 if p.inventory[name]==0 then p.inventory[name]=nil end
 sync(src);return true
end
local function setJob(src,job,grade)
 local p=Players[src];grade=tonumber(grade)
 if not p or not Config.Jobs[job] or not grade or grade%1~=0 or not Config.Jobs[job].grades[grade] then return false end
 p.job=job;p.grade=grade;p.metadata.duty=false;sync(src);return true
end
exports('GetPlayer',function(src) return Players[tonumber(src)] and public(Players[tonumber(src)]) or nil end)
exports('AddMoney',money)
exports('RemoveMoney',takeMoney)
exports('AddItem',addItem)
exports('RemoveItem',removeItem)
exports('SetJob',setJob)
exports('HasPermission',isAdmin)
exports('GetAllPlayers',function()
 local all={};for src,p in pairs(Players) do all[src]=public(p) end;return all
end)
local function reply(src,token,data)
 TriggerClientEvent('scoobz:response',src,token,data)
end
local handlers={}
handlers.characters=function(src)
 local ident=license(src);if not ident then return {error='Rockstar license not found'} end
 local rows=MySQL.query.await('SELECT id,firstname,lastname,dob,gender,job,grade FROM scoobz_characters WHERE license=? ORDER BY id LIMIT ?', {ident,Config.MaxCharacters})
 return {characters=rows}
end
handlers.create=function(src,data)
 local ident=license(src)
 if not ident or type(data)~='table' or not validName(data.firstname) or not validName(data.lastname) or type(data.dob)~='string' or not data.dob:match('^%d%d%d%d%-%d%d%-%d%d$') or (data.gender~='male' and data.gender~='female' and data.gender~='other') then
  return {error='Invalid character information'}
 end
 local n=MySQL.scalar.await('SELECT COUNT(*) FROM scoobz_characters WHERE license=?',{ident})
 if n>=Config.MaxCharacters then return {error='Character limit reached'} end
 local inv={phone=1,water=2,sandwich=2}
 local id=MySQL.insert.await('INSERT INTO scoobz_characters (license,firstname,lastname,dob,gender,cash,bank,job,grade,inventory,position,metadata) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
  {ident,data.firstname,data.lastname,data.dob,data.gender,Config.StartingCash,Config.StartingBank,'unemployed',0,json.encode(inv),json.encode(Config.DefaultSpawn),json.encode({hunger=100,thirst=100})})
 log('CREATE CHARACTER',id);return {success=true,id=id}
end
handlers.select=function(src,data)
 local ident=license(src);local id=tonumber(data and data.id)
 if not ident or not id or id%1~=0 then return {error='Invalid character'} end
 if Players[src] then return {error='Character already loaded'} end
 local row=MySQL.single.await('SELECT * FROM scoobz_characters WHERE id=? AND license=?',{id,ident})
 if not row then return {error='Character not owned'} end
 local inv=decode(row.inventory,{})
 for name,num in pairs(inv) do
  if not Config.Items[name] or type(num)~='number' or num%1~=0 or num<=0 then inv[name]=nil end
 end
 Players[src]={id=row.id,license=ident,firstname=row.firstname,lastname=row.lastname,dob=row.dob,gender=row.gender,cash=row.cash,bank=row.bank,job=Config.Jobs[row.job] and row.job or 'unemployed',grade=row.grade,inventory=inv,position=decode(row.position,Config.DefaultSpawn),metadata=decode(row.metadata,{hunger=100,thirst=100,duty=false})}
 sync(src);log('CHARACTER LOADED',('%d (%d)'):format(id,src));return {success=true,player=public(Players[src])}
end
handlers.shop=function(src,data)
 local p=Players[src];if not p then return {error='No active character'} end
 local index=tonumber(data and data.shop);local item=data and data.item;local count=tonumber(data and data.count)
 local shop=index and Config.Shops[index]
 if not shop or not count or count%1~=0 or count<1 or count>50 or not shop.items[item] then return {error='Invalid purchase'} end
 local ped=GetPlayerPed(src)
 if not ped or ped==0 then return {error='Player ped unavailable'} end
 local coords=GetEntityCoords(ped)
 local dest=vector3(shop.coords.x,shop.coords.y,shop.coords.z)
 if #(coords-dest)>5.0 then return {error='Too far from shop'} end
 local price=shop.items[item]*count
 if p.cash<price then return {error='Insufficient cash'} end
 if not addItem(src,item,count) then return {error='Inventory full'} end
 takeMoney(src,'cash',price);return {success=true}
end
handlers.use=function(src,data)
 local p=Players[src];local name=data and data.item
 if not p or (p.inventory[name] or 0)<1 then return {error='Item not available'} end
 if name~='water' and name~='sandwich' and name~='bandage' then return {error='Item not usable'} end
 if not removeItem(src,name,1) then return {error='Cannot use item'} end
 if name=='water' then p.metadata.thirst=math.min(100,(p.metadata.thirst or 0)+30)
 elseif name=='sandwich' then p.metadata.hunger=math.min(100,(p.metadata.hunger or 0)+30)
 else TriggerClientEvent('scoobz:healBandage',src) end
 sync(src);return {success=true}
end
handlers.bank=function(src,data)
 local p=Players[src];local amount=tonumber(data and data.amount)
 if not p or not amount or amount%1~=0 or amount<1 or amount>1000000 then return {error='Invalid amount'} end
 if data.action=='deposit' then
  if not takeMoney(src,'cash',amount) then return {error='Insufficient cash'} end
  money(src,'bank',amount)
 elseif data.action=='withdraw' then
  if not takeMoney(src,'bank',amount) then return {error='Insufficient bank balance'} end
  money(src,'cash',amount)
 else return {error='Unknown action'} end
 return {success=true}
end
handlers.vehicles=function(src)
 local p=Players[src];if not p then return {error='No active character'} end
 return {vehicles=MySQL.query.await('SELECT id,plate,model,stored FROM scoobz_vehicles WHERE owner_id=?',{p.id})}
end
handlers.spawnVehicle=function(src,data)
 local p=Players[src];local id=tonumber(data and data.id);local garage=Config.Garages[tonumber(data and data.garage) or 0]
 if not p or not id or not garage then return {error='Invalid vehicle request'} end
 local ped=GetPlayerPed(src);if not ped or ped==0 or #(GetEntityCoords(ped)-vector3(garage.coords.x,garage.coords.y,garage.coords.z))>7.0 then return {error='Not at garage'} end
 local row=MySQL.single.await('SELECT id,model,plate,stored FROM scoobz_vehicles WHERE id=? AND owner_id=?',{id,p.id})
 if not row or row.stored~=1 then return {error='Vehicle unavailable'} end
 local changed=MySQL.update.await('UPDATE scoobz_vehicles SET stored=0 WHERE id=? AND owner_id=? AND stored=1',{id,p.id})
 if changed~=1 then return {error='Vehicle already outside'} end
 TriggerClientEvent('scoobz:spawnOwnedVehicle',src,row,garage.spawn)
 return {success=true}
end
handlers.storeVehicle=function(src,data)
 local p=Players[src];local plate=type(data and data.plate)=='string' and data.plate or ''
 if not p or #plate>10 or #plate<1 then return {error='Invalid vehicle'} end
 local ped=GetPlayerPed(src);local veh=ped~=0 and GetVehiclePedIsIn(ped,false) or 0
 if veh==0 or GetPedInVehicleSeat(veh,-1)~=ped or GetVehicleNumberPlateText(veh):gsub('%s+$','')~=plate then return {error='Enter your owned vehicle as driver'} end
 local near=false
 for _,g in ipairs(Config.Garages) do if #(GetEntityCoords(ped)-vector3(g.coords.x,g.coords.y,g.coords.z))<18.0 then near=true end end
 if not near then return {error='Not near a garage'} end
 local changed=MySQL.update.await('UPDATE scoobz_vehicles SET stored=1 WHERE owner_id=? AND plate=? AND stored=0',{p.id,plate})
 if changed~=1 then return {error='Vehicle not registered to you or already stored'} end
 TriggerClientEvent('scoobz:deleteCurrentVehicle',src);return {success=true}
end

-- Scoobz Framework v1.5 extensions: all mutable operations run on the server.
local RateLimits = {}
local function limited(src, key, ms)
 local id=tostring(src)..':'..key
 local now=GetGameTimer()
 if RateLimits[id] and now-RateLimits[id]<ms then return true end
 RateLimits[id]=now
 return false
end
local function validAmount(n)
 return type(n)=='number' and n==n and n%1==0 and n>=1 and n<=1000000
end
local function audit(src,action,target,details)
 local actor=Players[src]
 local actorId=actor and actor.id or nil
 local targetId=target and target.id or nil
 local ok,err=pcall(function()
  MySQL.insert.await('INSERT INTO scoobz_audit (actor_character_id,target_character_id,action,details) VALUES (?,?,?,?)',
   {actorId,targetId,action,json.encode(details or {})})
 end)
 if not ok then log('AUDIT ERROR',err) end
end
handlers.toggleDuty=function(src)
 local p=Players[src]
 if not p then return {error='Select a character first'} end
 if p.job=='unemployed' then return {error='Civilians do not have a duty toggle'} end
 if limited(src,'duty',2000) then return {error='Please wait before changing duty'} end
 p.metadata.duty=not (p.metadata.duty==true)
 sync(src)
 audit(src,'duty',p,{job=p.job,duty=p.metadata.duty})
 return {success=true,duty=p.metadata.duty}
end
handlers.transfer=function(src,data)
 local from=Players[src]
 if not from then return {error='No active character'} end
 if limited(src,'transfer',3000) then return {error='Slow down'} end
 local targetId=tonumber(data and data.target)
 local amount=tonumber(data and data.amount)
 if not validAmount(amount) or not targetId or targetId%1~=0 then return {error='Invalid transfer'} end
 local target=Players[targetId]
 if not target or targetId==src or target.id==from.id then return {error='Recipient must be another online player'} end
 if from.bank<amount or target.bank+amount>1000000000 then return {error='Insufficient funds or recipient balance limit'} end
 -- No yield between debit and credit: both memory changes occur in one server scheduler turn.
 from.bank=from.bank-amount
 target.bank=target.bank+amount
 sync(src);sync(targetId)
 audit(src,'bank_transfer',target,{amount=amount})
 notify(targetId,('Received bank transfer: $%d'):format(amount))
 return {success=true}
end
handlers.myTransactions=function(src)
 local p=Players[src]
 if not p then return {error='No character'} end
 local rows=MySQL.query.await('SELECT action,details,created_at FROM scoobz_audit WHERE actor_character_id=? OR target_character_id=? ORDER BY id DESC LIMIT 30',{p.id,p.id})
 return {success=true,transactions=rows}
end
exports('GetBalance',function(src,account)
 local p=Players[tonumber(src)]
 if not p or (account~='cash' and account~='bank') then return nil end
 return p[account]
end)
exports('GetItemCount',function(src,item)
 local p=Players[tonumber(src)]
 if not p or type(item)~='string' then return 0 end
 return p.inventory[item] or 0
end)
exports('IsOnDuty',function(src)
 local p=Players[tonumber(src)]
 return p~=nil and p.metadata.duty==true
end)
exports('SetDuty',function(src,status)
 local p=Players[tonumber(src)]
 if not p or p.job=='unemployed' or type(status)~='boolean' then return false end
 p.metadata.duty=status;sync(tonumber(src));return true
end)
exports('SetMetadata',function(src,key,value)
 local p=Players[tonumber(src)]
 if not p or type(key)~='string' or not key:match('^[%w_]+$') or #key>32 or key=='duty' then return false end
 if type(value)~='number' and type(value)~='boolean' and type(value)~='string' then return false end
 if type(value)=='string' and #value>256 then return false end
 if (key=='hunger' or key=='thirst') and (type(value)~='number' or value~=value or value<0 or value>100) then return false end
 p.metadata[key]=value;sync(tonumber(src));return true
end)
exports('GetMetadata',function(src,key)
 local p=Players[tonumber(src)]
 return p and p.metadata[key] or nil
end)
exports('Notify',notify)
AddEventHandler('playerDropped',function()
 local prefix=tostring(source)..':'
 for key in pairs(RateLimits) do if key:sub(1,#prefix)==prefix then RateLimits[key]=nil end end
end)
RegisterCommand('duty',function(src)
 if src==0 then return end
 local result=handlers.toggleDuty(src)
 if result.error then notify(src,result.error) else notify(src,result.duty and 'You are now on duty' or 'You are now off duty') end
end,false)
RegisterCommand('pay',function(src,args)
 if src==0 then return end
 local result=handlers.transfer(src,{target=args[1],amount=args[2]})
 if result.error then notify(src,result.error) else notify(src,'Bank transfer completed') end
end,false)
RegisterCommand('mytransactions',function(src)
 if src==0 then return end
 local result=handlers.myTransactions(src)
 if result.error then return notify(src,result.error) end
 notify(src,('Recent recorded actions: %d (see server-side audit table)'):format(#result.transactions))
end,false)

RegisterNetEvent('scoobz:request',function(token,action,data)
 local src=source
 if type(token)~='number' or token%1~=0 or token<1 or token>1000000000 or type(action)~='string' then return end
 if Busy[src] then return reply(src,token,{error='Request still processing'}) end
 local fn=handlers[action];if not fn then return reply(src,token,{error='Unknown action'}) end
 Busy[src]=true
 local ok,result=pcall(fn,src,data)
 Busy[src]=nil
 if not ok then log('REQUEST ERROR',result);reply(src,token,{error='Server request failed'}) else reply(src,token,result or {}) end
end)
RegisterNetEvent('scoobz:updatePosition',function(pos)
 local src=source;local p=Players[src]
 if not p or type(pos)~='table' then return end
 for _,k in ipairs({'x','y','z','w'}) do if type(pos[k])~='number' or pos[k]~=pos[k] or math.abs(pos[k])>100000 then return end end
 local ped=GetPlayerPed(src)
 if ped==0 then return end
 local real=GetEntityCoords(ped)
 if #(real-vector3(pos.x,pos.y,pos.z))>30 then return end
 p.position=pos
end)
AddEventHandler('playerDropped',function() local src=source;save(src);Players[src]=nil;Busy[src]=nil end)
CreateThread(function()
 while true do
  Wait(Config.AutosaveMs)
  for src in pairs(Players) do save(src) end
 end
end)
CreateThread(function()
 while true do
  Wait(Config.PaycheckMs)
  for src,p in pairs(Players) do
   local job=Config.Jobs[p.job];local grade=job and job.grades[p.grade]
   if grade and (p.job=='unemployed' or p.metadata.duty==true) then money(src,'bank',grade.salary);notify(src,('Paycheck received: $%d'):format(grade.salary)) end
  end
 end
end)
RegisterCommand('scoobzsave',function(src)
 if src~=0 and not isAdmin(src) then return end
 for id in pairs(Players) do save(id) end;log('SAVE','Completed')
end,true)
RegisterCommand('setjob',function(src,args)
 if not isAdmin(src) then return notify(src,'No permission') end
 local target=tonumber(args[1]);if target and setJob(target,args[2],args[3]) then notify(target,'Your job was updated');notify(src,'Job set') else notify(src,'Usage: /setjob [id] [job] [grade]') end
end,false)
RegisterCommand('givemoney',function(src,args)
 if not isAdmin(src) then return notify(src,'No permission') end
 local target=tonumber(args[1]);if target and money(target,args[2],args[3]) then notify(src,'Money added') else notify(src,'Usage: /givemoney [id] [cash|bank] [amount]') end
end,false)
RegisterCommand('giveitem',function(src,args)
 if not isAdmin(src) then return notify(src,'No permission') end
 local target=tonumber(args[1]);if target and addItem(target,args[2],args[3]) then notify(src,'Item added') else notify(src,'Usage: /giveitem [id] [item] [count]') end
end,false)
RegisterCommand('givecar',function(src,args)
 if not isAdmin(src) then return notify(src,'No permission') end
 local target=tonumber(args[1]);local p=target and Players[target];local model=args[2]
 if not p or type(model)~='string' or not model:match('^[%w_]+$') or #model>40 then return notify(src,'Usage: /givecar [id] [vehiclemodel]') end
 local plate=('SZ%06d'):format(math.random(0,999999))
 local ok,id=pcall(function()return MySQL.insert.await('INSERT INTO scoobz_vehicles (owner_id,plate,model,props,stored) VALUES (?,?,?,?,1)',{p.id,plate,model,'{}'})end)
 if ok then notify(src,'Vehicle registered: '..plate);notify(target,'New garage vehicle: '..plate) else notify(src,'Vehicle registration failed (try again)') end
end,false)
AddEventHandler('onResourceStop',function(resource)
 if resource==GetCurrentResourceName() then for src in pairs(Players) do save(src) end end
end)
log('START','Scoobz Framework v1.5.0 loaded')
